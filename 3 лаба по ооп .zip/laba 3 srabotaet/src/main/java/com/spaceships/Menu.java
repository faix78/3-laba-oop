package com.spaceships;

import com.spaceships.dao.CombatShipDAO;
import com.spaceships.dao.CosmicShipDAO;
import com.spaceships.dao.ResearchShipDAO;
import com.spaceships.entity.CombatShip;
import com.spaceships.entity.CosmicShip;
import com.spaceships.entity.ResearchShip;

import java.util.List;
import java.util.Scanner;

public class Menu {
    private final CosmicShipDAO cosmicShipDAO = new CosmicShipDAO();
    private final CombatShipDAO combatShipDAO = new CombatShipDAO();
    private final ResearchShipDAO researchShipDAO = new ResearchShipDAO();
    private final Scanner scanner = new Scanner(System.in);

    public void mainMenu() {
        while (true) {
            clearScreen();
            System.out.println("\nВыберите действие:");
            System.out.println("1. Создать боевой корабль");
            System.out.println("2. Создать исследовательский корабль");
            System.out.println("3. Создать свой корабль");
            System.out.println("4. Просмотреть созданные корабли");
            System.out.println("5. Выход");
            System.out.print("Ваш выбор: ");

            int choice;
            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Ошибка ввода, попробуйте снова.");
                pause();
                continue;
            }

            switch (choice) {
                case 1 -> {
                    CombatShip combat = new CombatShip();
                    combat.setName("Истребитель");
                    combat.setMaxSpeed(5000);
                    combat.setWeaponPower(80);
                    combat.setArmorLevel(50);
                    combatShipDAO.save(combat);
                    shipMenu(combat);
                }
                case 2 -> {
                    ResearchShip research = new ResearchShip();
                    research.setName("Исследователь");
                    research.setMaxSpeed(3000);
                    research.setScanRange(1000);
                    research.setStorageVolume(50);
                    researchShipDAO.save(research);
                    shipMenu(research);
                }
                case 3 -> createCustomShip();
                case 4 -> viewShipsMenu();
                case 5 -> {
                    System.out.println("Выход из программы. Все корабли сохранены в базе данных.");
                    return;
                }
                default -> {
                    System.out.println("Ошибка ввода, попробуйте снова.");
                    pause();
                }
            }
        }
    }

    private void shipMenu(CosmicShip ship) {
        while (true) {
            clearScreen();
            System.out.println("\nМеню корабля (" + ship.getShipType() + ")");
            System.out.println("1. Показать информацию");
            System.out.println("2. Специальные свойства");
            System.out.println("3. Методы (начало/конец миссии)");
            System.out.println("4. Переопределяющие методы");
            System.out.println("5. Специальные методы");
            System.out.println("6. Редактировать корабль");
            System.out.println("7. Удалить корабль");
            System.out.println("8. Вернуться назад");
            System.out.print("Ваш выбор: ");

            int choice;
            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Ошибка ввода, попробуйте снова.");
                pause();
                continue;
            }

            switch (choice) {
                case 1:
                    ship.showInfo();
                    break;
                case 2:
                    System.out.println("\n*** Специальные свойства ***");
                    System.out.println("Свойство 1: " + ship.getSpecialProperty1());
                    System.out.println("Свойство 2: " + ship.getSpecialProperty2());
                    break;
                case 3:
                    System.out.println("\n*** Методы (начало/конец миссии) ***");
                    System.out.println("1. Начать миссию");
                    System.out.println("2. Завершить миссию");
                    System.out.println("3. Вернуться назад");
                    int methodChoice;
                    try {
                        methodChoice = Integer.parseInt(scanner.nextLine());
                    } catch (NumberFormatException e) {
                        System.out.println("Неверный выбор.");
                        pause();
                        break;
                    }
                    if (methodChoice == 1) ship.startMission();
                    else if (methodChoice == 2) ship.endMission();
                    else if (methodChoice != 3) System.out.println("Неверный выбор.");
                    break;
                case 4:
                    System.out.println("\n*** Переопределяющие методы ***");
                    System.out.println("1. Рассчитать траекторию");
                    System.out.println("2. Определить расход топлива");
                    System.out.println("3. Выбрать миссию");
                    System.out.println("4. Вернуться назад");
                    int overrideChoice;
                    try {
                        overrideChoice = Integer.parseInt(scanner.nextLine());
                    } catch (NumberFormatException e) {
                        System.out.println("Неверный выбор.");
                        pause();
                        break;
                    }
                    if (overrideChoice == 1) ship.calculateTrajectory();
                    else if (overrideChoice == 2) ship.determineFuelConsumption();
                    else if (overrideChoice == 3) ship.selectMission();
                    else if (overrideChoice != 4) System.out.println("Неверный выбор.");
                    break;
                case 5:
                    System.out.println("\n*** Специальные методы ***");
                    System.out.println("1. Действие 1");
                    System.out.println("2. Действие 2");
                    System.out.println("3. Вернуться назад");
                    int specialChoice;
                    try {
                        specialChoice = Integer.parseInt(scanner.nextLine());
                    } catch (NumberFormatException e) {
                        System.out.println("Неверный выбор.");
                        pause();
                        break;
                    }
                    if (specialChoice == 1) ship.specialAction1();
                    else if (specialChoice == 2) ship.specialAction2();
                    else if (specialChoice != 3) System.out.println("Неверный выбор.");
                    break;
                case 6:
                    editShip(ship);
                    break;
                case 7:
                    deleteShip(ship);
                    return;
                case 8:
                    return;
                default:
                    System.out.println("Ошибка ввода, попробуйте снова.");
                    pause();
            }
            pause();
        }
    }

    private void createCustomShip() {
        clearScreen();
        System.out.println("Выберите тип корабля:");
        System.out.println("1. Боевой корабль");
        System.out.println("2. Исследовательский корабль");
        System.out.print("Ваш выбор: ");
        int type;
        try {
            type = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Неверный выбор, установлен боевой по умолчанию.");
            type = 1;
        }

        System.out.print("Введите название корабля: ");
        String name = scanner.nextLine().trim();

        System.out.print("Введите максимальную скорость (максимум 10000 км/с): ");
        double maxSpeed;
        try {
            maxSpeed = Double.parseDouble(scanner.nextLine());
            maxSpeed = Math.max(0, Math.min(maxSpeed, 10000));
        } catch (NumberFormatException e) {
            System.out.println("Ошибка ввода, установлена максимальная скорость: 10000.");
            maxSpeed = 10000;
        }

        if (type == 1) {
            System.out.print("Введите мощность оружия (максимум 100): ");
            int weaponPower;
            try {
                weaponPower = Integer.parseInt(scanner.nextLine());
                weaponPower = Math.max(0, Math.min(weaponPower, 100));
            } catch (NumberFormatException e) {
                System.out.println("Ошибка ввода, установлена максимальная мощность: 100.");
                weaponPower = 100;
            }

            System.out.print("Введите уровень брони (максимум 100): ");
            int armorLevel;
            try {
                armorLevel = Integer.parseInt(scanner.nextLine());
                armorLevel = Math.max(0, Math.min(armorLevel, 100));
            } catch (NumberFormatException e) {
                System.out.println("Ошибка ввода, установлен максимальный уровень: 100.");
                armorLevel = 100;
            }

            CombatShip combat = new CombatShip();
            combat.setName(name);
            combat.setMaxSpeed(maxSpeed);
            combat.setWeaponPower(weaponPower);
            combat.setArmorLevel(armorLevel);
            combatShipDAO.save(combat);
            shipMenu(combat);
        } else {
            System.out.print("Введите радиус сканирования (максимум 5000 км): ");
            int scanRange;
            try {
                scanRange = Integer.parseInt(scanner.nextLine());
                scanRange = Math.max(0, Math.min(scanRange, 5000));
            } catch (NumberFormatException e) {
                System.out.println("Ошибка ввода, установлен максимальный радиус: 5000.");
                scanRange = 5000;
            }

            System.out.print("Введите объем хранилища (максимум 1000 TB): ");
            int storageVolume;
            try {
                storageVolume = Integer.parseInt(scanner.nextLine());
                storageVolume = Math.max(0, Math.min(storageVolume, 1000));
            } catch (NumberFormatException e) {
                System.out.println("Ошибка ввода, установлен максимальный объем: 1000.");
                storageVolume = 1000;
            }

            ResearchShip research = new ResearchShip();
            research.setName(name);
            research.setMaxSpeed(maxSpeed);
            research.setScanRange(scanRange);
            research.setStorageVolume(storageVolume);
            researchShipDAO.save(research);
            shipMenu(research);
        }
    }

    private void editShip(CosmicShip ship) {
        clearScreen();
        System.out.println("Редактирование корабля: " + ship.getName());
        System.out.print("Введите новое название корабля (текущее: " + ship.getName() + "): ");
        String name = scanner.nextLine().trim();
        if (!name.isEmpty()) {
            ship.setName(name);
        }

        System.out.print("Введите новую максимальную скорость (текущее: " + ship.getMaxSpeed() + " км/с, максимум 10000): ");
        String maxSpeedInput = scanner.nextLine();
        if (!maxSpeedInput.isEmpty()) {
            try {
                double maxSpeed = Double.parseDouble(maxSpeedInput);
                maxSpeed = Math.max(0, Math.min(maxSpeed, 10000));
                ship.setMaxSpeed(maxSpeed);
            } catch (NumberFormatException e) {
                System.out.println("Неверный ввод, скорость не изменена.");
            }
        }

        if (ship instanceof CombatShip combatShip) {
            System.out.print("Введите новую мощность оружия (текущее: " + combatShip.getWeaponPower() + ", максимум 100): ");
            String weaponPowerInput = scanner.nextLine();
            if (!weaponPowerInput.isEmpty()) {
                try {
                    int weaponPower = Integer.parseInt(weaponPowerInput);
                    weaponPower = Math.max(0, Math.min(weaponPower, 100));
                    combatShip.setWeaponPower(weaponPower);
                } catch (NumberFormatException e) {
                    System.out.println("Неверный ввод, мощность оружия не изменена.");
                }
            }

            System.out.print("Введите новый уровень брони (текущее: " + combatShip.getArmorLevel() + ", максимум 100): ");
            String armorLevelInput = scanner.nextLine();
            if (!armorLevelInput.isEmpty()) {
                try {
                    int armorLevel = Integer.parseInt(armorLevelInput);
                    armorLevel = Math.max(0, Math.min(armorLevel, 100));
                    combatShip.setArmorLevel(armorLevel);
                } catch (NumberFormatException e) {
                    System.out.println("Неверный ввод, уровень брони не изменен.");
                }
            }
            combatShipDAO.update(combatShip);
        } else if (ship instanceof ResearchShip researchShip) {
            System.out.print("Введите новый радиус сканирования (текущее: " + researchShip.getScanRange() + " км, максимум 5000): ");
            String scanRangeInput = scanner.nextLine();
            if (!scanRangeInput.isEmpty()) {
                try {
                    int scanRange = Integer.parseInt(scanRangeInput);
                    scanRange = Math.max(0, Math.min(scanRange, 5000));
                    researchShip.setScanRange(scanRange);
                } catch (NumberFormatException e) {
                    System.out.println("Неверный ввод, радиус сканирования не изменен.");
                }
            }

            System.out.print("Введите новый объем хранилища (текущее: " + researchShip.getStorageVolume() + " TB, максимум 1000): ");
            String storageVolumeInput = scanner.nextLine();
            if (!storageVolumeInput.isEmpty()) {
                try {
                    int storageVolume = Integer.parseInt(storageVolumeInput);
                    storageVolume = Math.max(0, Math.min(storageVolume, 1000));
                    researchShip.setStorageVolume(storageVolume);
                } catch (NumberFormatException e) {
                    System.out.println("Неверный ввод, объем хранилища не изменен.");
                }
            }
            researchShipDAO.update(researchShip);
        }
        System.out.println("Корабль успешно обновлен.");
    }

    private void deleteShip(CosmicShip ship) {
        clearScreen();
        System.out.println("Вы уверены, что хотите удалить корабль: " + ship.getName() + "?");
        System.out.println("1. Да");
        System.out.println("2. Нет");
        System.out.print("Ваш выбор: ");
        int choice;
        try {
            choice = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Неверный выбор, удаление отменено.");
            pause();
            return;
        }
        if (choice == 1) {
            if (ship instanceof CombatShip) {
                combatShipDAO.delete(ship.getId());
            } else if (ship instanceof ResearchShip) {
                researchShipDAO.delete(ship.getId());
            }
            System.out.println("Корабль " + ship.getName() + " успешно удален.");
        } else {
            System.out.println("Удаление отменено.");
        }
        pause();
    }

    private void viewShipsMenu() {
        List<CombatShip> combatShips = combatShipDAO.findAll();
        List<ResearchShip> researchShips = researchShipDAO.findAll();

        if (combatShips.isEmpty() && researchShips.isEmpty()) {
            System.out.println("\nСписок кораблей пуст. Сначала создайте корабль.");
            System.out.println("Нажмите Enter для возврата.");
            pause();
            return;
        }

        while (true) {
            clearScreen();
            System.out.println("\nСписок созданных кораблей:");
            int index = 1;
            for (CombatShip ship : combatShips) {
                System.out.println(index++ + ". " + ship.getName() + " (Боевой)");
            }
            for (ResearchShip ship : researchShips) {
                System.out.println(index++ + ". " + ship.getName() + " (Исследовательский)");
            }
            System.out.println(index + ". Вернуться назад");
            System.out.print("Выберите корабль: ");
            int choice;
            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Ошибка ввода, попробуйте снова.");
                pause();
                continue;
            }

            if (choice == index) {
                return;
            } else if (choice > 0 && choice <= (combatShips.size() + researchShips.size())) {
                if (choice <= combatShips.size()) {
                    shipMenu(combatShips.get(choice - 1));
                } else {
                    shipMenu(researchShips.get(choice - 1 - combatShips.size()));
                }
            } else {
                System.out.println("Неверный выбор, попробуйте снова.");
                pause();
            }
        }
    }

    private void clearScreen() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

    private void pause() {
        System.out.println("\nНажмите Enter для продолжения...");
        scanner.nextLine();
    }
}