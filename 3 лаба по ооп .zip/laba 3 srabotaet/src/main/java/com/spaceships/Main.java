package com.spaceships;

import com.spaceships.util.HibernateUtil;

public class Main {
    public static void main(String[] args) {
        try {
            Menu menu = new Menu();
            menu.mainMenu();
        } finally {
            HibernateUtil.shutdown();
        }
    }

}