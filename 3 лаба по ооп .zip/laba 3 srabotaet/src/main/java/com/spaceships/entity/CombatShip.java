package com.spaceships.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "combat_ships")
public class CombatShip extends CosmicShip {
    @Id
    private Long id; // Унаследовано от CosmicShip через JOINED

    @Column(name = "weapon_power", nullable = false)
    private int weaponPower;

    @Column(name = "armor_level", nullable = false)
    private int armorLevel;

    public CombatShip() {
        setShipType("Combat");
    }

    @Override
    public void showInfo() {
        System.out.println("\n*** Combat Ship ***");
        System.out.println("Name: " + getName());
        System.out.println("Max Speed: " + getMaxSpeed() + " km/s");
        System.out.println("Weapon Power: " + weaponPower);
        System.out.println("Armor Level: " + armorLevel);
    }

    @Override
    public void calculateTrajectory() {
        System.out.println("Calculating trajectory for combat ship: Optimized for maneuverability.");
    }

    @Override
    public void determineFuelConsumption() {
        double fuel = getMaxSpeed() * 0.5 + weaponPower * 0.3;
        System.out.println("Fuel consumption calculated: " + fuel + " units per hour.");
    }

    @Override
    public void selectMission() {
        System.out.println("Select combat mission:");
        System.out.println("1. Attack");
        System.out.println("2. Base Defense");
        System.out.print("Your choice: ");
        // Реализация ввода в Menu.java
    }

    @Override
    public void specialAction1() {
        System.out.println("Attacking target: Weapons activated, power " + weaponPower + "!");
    }

    @Override
    public void specialAction2() {
        System.out.println("Reinforcing armor: Current armor level increased by 10.");
        armorLevel += 10;
    }

    @Override
    public int getSpecialProperty1() {
        return weaponPower;
    }

    @Override
    public int getSpecialProperty2() {
        return armorLevel;
    }
}