package com.spaceships.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "research_ships")
public class ResearchShip extends CosmicShip {
    @Id
    private Long id; // Унаследовано от CosmicShip

    @Column(name = "scan_range", nullable = false)
    private int scanRange;

    @Column(name = "storage_volume", nullable = false)
    private int storageVolume;

    public ResearchShip() {
        setShipType("Research");
    }

    @Override
    public void showInfo() {
        System.out.println("\n*** Research Ship ***");
        System.out.println("Name: " + getName());
        System.out.println("Max Speed: " + getMaxSpeed() + " km/s");
        System.out.println("Scan Range: " + scanRange + " km");
        System.out.println("Storage Volume: " + storageVolume + " TB");
    }

    @Override
    public void calculateTrajectory() {
        System.out.println("Calculating trajectory for research ship: Optimized for fuel efficiency.");
    }

    @Override
    public void determineFuelConsumption() {
        double fuel = getMaxSpeed() * 0.3 + scanRange * 0.1;
        System.out.println("Fuel consumption calculated: " + fuel + " units per hour.");
    }

    @Override
    public void selectMission() {
        System.out.println("Select research mission:");
        System.out.println("1. Space Exploration");
        System.out.println("2. Successful Landing");
        System.out.print("Your choice: ");
        // Реализация ввода в Menu.java
    }

    @Override
    public void specialAction1() {
        System.out.println("Scanning area: Radius " + scanRange + " km, data collected.");
    }

    @Override
    public void specialAction2() {
        System.out.println("Saving data: Volume " + storageVolume + " TB filled.");
    }

    @Override
    public int getSpecialProperty1() {
        return scanRange;
    }

    @Override
    public int getSpecialProperty2() {
        return storageVolume;
    }
}