package com.spaceships.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "cosmic_ships")
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class CosmicShip {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(name = "max_speed", nullable = false)
    private double maxSpeed;

    @Column(name = "ship_type", nullable = false)
    private String shipType;

    public void startMission() {
        System.out.println("\nMission started! Preparing for launch...");
        try {
            for (int i = 0; i < 5; i++) {
                System.out.print("* ");
                Thread.sleep(300);
            }
            System.out.println(" Launch!");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    public void endMission() {
        System.out.println("\nMission completed! Returning to base.");
    }

    public void adjustSystems() {
        System.out.println("Adjusting systems: General parameters set.");
    }

    public void selectMission() {
        System.out.println("Selecting mission: Preparing for standard mission.");
    }

    public void calculateTrajectory() {
        System.out.println("Trajectory calculation not implemented.");
    }

    public void determineFuelConsumption() {
        System.out.println("Fuel consumption calculation not implemented.");
    }

    public abstract void showInfo();

    public void specialAction1() {
        System.out.println("Action not supported for this ship type.");
    }

    public void specialAction2() {
        System.out.println("Action not supported for this ship type.");
    }

    public int getSpecialProperty1() {
        return 0;
    }

    public int getSpecialProperty2() {
        return 0;
    }
}